﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Text;

namespace SimpleDialogExample
{
    [Serializable]
    public class SimpleDialog : IDialog<string>
    {
        public async Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageHandler);

        }

        private async Task MessageHandler(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;
            await context.PostAsync("You said: " + message.Text);

            StringBuilder returnMessage = new StringBuilder();
            string language = "en";
            string word_id = message.Text;

            string url = "https://od-api.oxforddictionaries.com:443/api/v1/entries/" + language + "/" + word_id + "/synonyms";

            using (var httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Add("ContentType", "application/json");
                httpClient.DefaultRequestHeaders.Add("app_id", "294b41ad");
                httpClient.DefaultRequestHeaders.Add("app_key", "6ae4a7a761884936995f7d875ef479eb");

                try
                {

                    var response = await httpClient.GetStringAsync(new Uri(url));

                    dynamic rr = JsonConvert.DeserializeObject(response);
                    foreach (var obj in rr.results)
                    {
                        foreach (var obj1 in obj.lexicalEntries)
                        {
                            foreach (var obj2 in obj1.entries)
                            {
                                foreach (var obj3 in obj2.senses)
                                {
                                    foreach (var obj4 in obj3.synonyms)
                                    {
                                        returnMessage.Append(obj4.text);
                                        returnMessage.Append(" , ");
                                    }
                                }
                            }
                        }
                    }

                }
                catch (Exception ex)
                {

                    await context.PostAsync(ex.ToString());
                }

            }
            await context.PostAsync("Synonyms for your word : " + message.Text + " are ");
            await context.PostAsync(returnMessage.ToString());
            context.Wait(MessageHandler);
        }
    }
}