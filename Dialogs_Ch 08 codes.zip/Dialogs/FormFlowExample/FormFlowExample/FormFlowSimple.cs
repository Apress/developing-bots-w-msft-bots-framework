﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder.FormFlow;

namespace FormFlowExample
{

    public enum Deliveryoptions
    {
        CashOnDelivery, CreditCard, DebitCard, Wallet, BitCoin
    }

    public enum RamOptions
    {
        TwoGB, FourGB, EightGB, SixteenGB
    }

    public enum ScreenSizeOptions
    {
        Small, Medium, Large
    }

    public enum DiskOptions
    {
        SSD, HybridDrive, MechanicalHardDrive
    }

    public enum CpuOptions
    {
        AMD, IntelCoreI5, IntelCoreI7, IntelPentium, IntelCeleron
    }

    public enum OperatingSystemOptions
    {
        DOS, Windows, Linux, Mac, Chrome
    }

    [Serializable]
    public class FormFlowSimple
    {
        public OperatingSystemOptions? OS;
        public CpuOptions? cpu;
        public DiskOptions? drive;
        public ScreenSizeOptions? screen;
        public RamOptions? ram;
        public Deliveryoptions? delivery;
        public string CreditCardNumber;

        public static IForm<FormFlowSimple> BuildForm()
        {
            return new FormBuilder<FormFlowSimple>().Message("Welcome to NoteBook builder..").Build();
        }
    }
}