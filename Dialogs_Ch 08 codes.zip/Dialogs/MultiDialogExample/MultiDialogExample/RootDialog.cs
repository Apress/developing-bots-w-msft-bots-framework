﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;

namespace MultiDialogExample
{
    [Serializable]
    public class RootDialog : IDialog<IMessageActivity>
    {
        public async Task StartAsync(IDialogContext context)
        {
            context.Wait<IMessageActivity>(start);
        }

        private async Task start(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            await context.PostAsync("Please provide your input !! Synonym or Antonym");
            context.Wait<IMessageActivity>(DecisionMaker);
        }

        private async Task DecisionMaker(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;

            if ("support" == message.Text.ToLower())
                await context.Forward(new Support(), SupportHandler, message, System.Threading.CancellationToken.None);
            else if ("synonym" == message.Text.ToLower())
                context.Call<bool>(new Synonym(), SynonymHandler);
            else if ("antonym" == message.Text.ToLower())
                context.Call<bool>(new Antonym(), SynonymHandler);
            else
               context.Wait(start);

        }

        private async Task SynonymHandler(IDialogContext context, IAwaitable<bool> result)
        {
            bool message = await result;
            await context.PostAsync("Please provide your input !! Synonym or Antonym");
            context.Wait<IMessageActivity>(DecisionMaker);
        }

        private async Task SupportHandler(IDialogContext context, IAwaitable<int> result)
        {
            var ticketNumber = await result;

            await context.PostAsync($"Thanks for contacting our support team. Your ticket number is {ticketNumber}.");
            context.Wait(start);
        }
    }
}