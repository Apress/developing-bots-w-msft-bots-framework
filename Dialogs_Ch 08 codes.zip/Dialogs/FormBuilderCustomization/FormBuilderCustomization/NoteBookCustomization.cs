﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder.FormFlow;

namespace FormBuilderCustomization
{

    public enum Deliveryoptions
    {
        CashOnDelivery, CreditCard, DebitCard, Wallet, BitCoin
    }

    public enum RamOptions
    {
        TwoGB, FourGB, EightGB, SixteenGB
    }

    public enum ScreenSizeOptions
    {
        Small, Medium, Large
    }

    public enum DiskOptions
    {
        SSD, HybridDrive, MechanicalHardDrive
    }

    public enum CpuOptions
    {
        AMD, IntelCoreI5, IntelCoreI7, IntelPentium, IntelCeleron
    }

    public enum OperatingSystemOptions
    {
        DOS, Windows, Linux, Mac, Chrome
    }

    [Serializable]
    public class FormFlowSimple
    {
        [Template(TemplateUsage.EnumSelectOne, "What is your preferred operating system? {||}")]
        public OperatingSystemOptions? OS;
        public CpuOptions? cpu;
        public DiskOptions? drive;
        public ScreenSizeOptions? screen;
        public RamOptions? ram;
        public Deliveryoptions? delivery;

        [Prompt("Please enter your Credit card Number in international format !!")]
        public string CreditCardNumber;

        public static IForm<FormFlowSimple> BuildForm()
        {
            return new FormBuilder<FormFlowSimple>()
                .Message("Welcome to NoteBook builder..")
                .Field(nameof(ram))
                .Field(nameof(cpu))
                .Field(nameof(drive))
                .Field(nameof(screen))
                .Field(nameof(OS))
                .Field(nameof(delivery))
                .Field(nameof(CreditCardNumber), IsCreditCard)
                .Build();
        }

        private static bool IsCreditCard(FormFlowSimple state)
        {
            return state.delivery == Deliveryoptions.CreditCard;
        }
    }
}