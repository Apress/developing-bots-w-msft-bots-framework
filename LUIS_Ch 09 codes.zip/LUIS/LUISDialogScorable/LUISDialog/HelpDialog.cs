﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;


namespace LUISDialog
{
    [Serializable]
    public class HelpDialog  : IDialog<object>
    {
        private readonly string _messageToSend;

        public HelpDialog(string message)
        {
            _messageToSend = message;
        }

        public async Task StartAsync(IDialogContext context)
        {
            await context.PostAsync(_messageToSend);
            context.Done<object>(null);
        }

    }
}