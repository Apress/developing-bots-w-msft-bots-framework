﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Internals;
using Microsoft.Bot.Builder.Internals.Fibers;
using Microsoft.Bot.Builder.Dialogs.Internals;
using Microsoft.Bot.Builder.Scorables.Internals;
using Microsoft.Bot.Connector;
using System.Threading;
using System.Threading.Tasks;

namespace LUISDialog
{
    public class GreetingsScorable : ScorableBase<IActivity, string, double>
    {

        private IDialogTask _task;
        public GreetingsScorable(IDialogTask task)
        {
            SetField.NotNull(out _task, nameof(task), task);
        }
        protected override Task DoneAsync(IActivity item, string state, CancellationToken token)
        {
            return Task.CompletedTask;
        }

        protected override bool HasScore(IActivity item, string state)
        {
            return state != null;
        }

        protected override double GetScore(IActivity item, string state)
        {
            return 1.0;
        }


        protected override async Task PostAsync(IActivity item, string state, CancellationToken token)
        {
            var message = item as IMessageActivity;

            if (message != null)
            {
                var incomingMessage = message.Text.ToLowerInvariant();
                var messageToSend = string.Empty;

                if (incomingMessage == "hello")
                    messageToSend = "Thanks for pinging me!! provide details about your travel";

                if (incomingMessage == "thank you")
                    messageToSend = "You are welcome and can always return back for further queries and travel bookings!";

                if (incomingMessage == "goodbye")
                    messageToSend = "See you later but remember to get back if you want to travel again!!";

                if (incomingMessage == "hi")
                    messageToSend = "Thanks for pinging me!! provide details about your travel";

                if (incomingMessage == "help")
                    messageToSend = "Please provide from and To location, date of travel to start the conversation !!";

                var abc = new HelpDialog(messageToSend);
                var interruption = abc.Void<object, IMessageActivity>();
                this._task.Call(interruption, null);
                await this._task.PollAsync(token);
            }
        }

        protected override async Task<string> PrepareAsync(IActivity item, CancellationToken token)
        {
            
            var message = item.AsMessageActivity();

            if (message != null && !string.IsNullOrWhiteSpace(message.Text))
            {
                var msg = message.Text.ToLowerInvariant();

                if (msg == "hello" || msg == "thank you" || msg == "goodbye" || msg == "hi" || msg == "help")
                {
                    return message.Text;
                }
            }

            return null;

        }
    }
}