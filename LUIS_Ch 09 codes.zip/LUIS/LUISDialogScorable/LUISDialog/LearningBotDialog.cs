﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Luis.Models;
using System.Threading;
using Microsoft.Bot.Connector;

namespace LUISDialog
{
    [LuisModel("e462d5c3-94f3-4eeb-b006-7d4f41875061" , "d431bf177c7140699e2f624f74b32468")]
    [Serializable]
    public class LearningBotDialog :LuisDialog<object>
    {
        [LuisIntent("")]
        public async Task None(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("I do not understand you!!");
            context.Wait(MessageReceived);
        }

        [LuisIntent("Flying")]
        public async Task Fly(IDialogContext context, LuisResult result)
        {
            await context.Forward(new FlyingDialog(), AfterMessagehandler, result, CancellationToken.None);
        }

        private async Task AfterMessagehandler(IDialogContext context, IAwaitable<bool> result)
        {
            bool message = await result;

            context.Wait(MessageReceived);
        }

        [LuisIntent("Driving")]
        public async Task Ground(IDialogContext context, LuisResult result)
        {
           await context.Forward(new GroundDialog(), AfterMessagehandler, result, CancellationToken.None);
           
        }
    }
}