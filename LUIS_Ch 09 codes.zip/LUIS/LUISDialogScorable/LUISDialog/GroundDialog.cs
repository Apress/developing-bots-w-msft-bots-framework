﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Builder.Luis.Models;
using System.Text;

namespace LUISDialog
{
    [Serializable]
    public class GroundDialog : IDialog<bool>
    {
        public async Task StartAsync(IDialogContext context)
        {
            await context.PostAsync("Thanks for booking with us!! please confirm your details");
            context.Wait<LuisResult>(BookGroundTrip);
        }

        private async Task BookGroundTrip(IDialogContext context, IAwaitable<LuisResult> result)
        {
            var message = await result;
            StringBuilder sb = new StringBuilder();

            var itemsMax = message.Intents.Where(x => x.Score == message.Intents.Max(y => y.Score)).First();
            sb.Append("Intent is " + itemsMax.Intent + Environment.NewLine + "\n");

            foreach (var d in message.Entities)
            {
                sb.Append("Entity type " + d.Type + " has value " + d.Entity + Environment.NewLine + "\n");
            }
            await context.PostAsync(sb.ToString());
            context.Done<bool>(true);
        }
    }
}