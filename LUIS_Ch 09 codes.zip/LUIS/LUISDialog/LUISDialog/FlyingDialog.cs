﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using System.Threading.Tasks;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Builder.Luis.Models;

namespace LUISDialog
{
    [Serializable]
    public class FlyingDialog : IDialog<bool>
    {
        public async Task StartAsync(IDialogContext context)
        {
            await context.PostAsync("thanks!! please confirm your detials");
            context.Wait<LuisResult>(BookFlightTrip);
        }

        private async Task BookFlightTrip(IDialogContext context, IAwaitable<LuisResult> result)
        {
            var message = await result;
            
            await context.PostAsync("Thanks for booking with us");
            await context.PostAsync(message.Entities[0].Entity.ToString());
            context.Done<bool>(true);
        }
    }
}