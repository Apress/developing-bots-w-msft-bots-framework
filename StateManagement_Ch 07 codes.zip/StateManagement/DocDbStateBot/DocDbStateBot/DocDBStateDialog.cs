﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Threading.Tasks;


namespace DialogStateExample
{
    [Serializable()]
    public class StateSampleDialog : IDialog<object>
    {

        public async Task StartAsync(IDialogContext context)
        {
            await context.PostAsync("Hi There!! Lets get started !!");
            context.Wait(GetStarted);
        }

        public virtual async Task GetStarted(IDialogContext context, IAwaitable<object> result)
        {
            var name = await result;


            await context.PostAsync("Please provide your name !!");
            context.Wait(NameFromUserMethod);
        }

        public virtual async Task NameFromUserMethod(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var name = await result;

            context.UserData.SetValue("username", name.Text);

            await context.PostAsync("Please provide your City name !!");
            context.Wait(CityFromUserMethod);
        }

        public virtual async Task CityFromUserMethod(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var city = await result;


            string userName = context.UserData.Get<string>("username");

            context.ConversationData.SetValue("cityname", city.Text);

            await context.PostAsync($"Hello {userName} !! you stay in {city.Text}..Provide a rating (1-10) for this conversation");
            context.Wait(RatingFromUserMethod);
        }

        public virtual async Task RatingFromUserMethod(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var rating = await result;

            string userName = context.UserData.Get<string>("username");
            string cityName = context.ConversationData.Get<string>("cityname");

            context.PrivateConversationData.SetValue("rating", rating.Text);

            await context.PostAsync($"Hello {userName} !! Enter 'over' to know your details !!");
            context.Wait(closingConversation);
        }

        public virtual async Task closingConversation(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var rating = await result;

            string userName = context.UserData.Get<string>("username");
            string cityName = context.ConversationData.Get<string>("cityname");
            string score = context.PrivateConversationData.Get<string>("rating");

            await context.PostAsync($"Hello {userName} !! you stay in {cityName}.. and you have rated this conversation with a score of {score} .. Thank you!!");
            context.Wait(NameFromUserMethod);
        }
    }
}