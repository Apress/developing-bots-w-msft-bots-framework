﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.Bot.Connector;
using System.Text;


namespace StateClientBot
{
    [BotAuthentication]
    public class MessagesController : ApiController
    {
        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// </summary>
        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            string myUserString = "";
            string myConversationString = "";
            string myPrivateConversationString = "";
            if (activity.Type == ActivityTypes.Message)
            {


                StringBuilder str = new StringBuilder();

                ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));


                StateClient sc = activity.GetStateClient();

                BotData userData = sc.BotState.GetUserData(activity.ChannelId, activity.From.Id);
                BotData conversationData = sc.BotState.GetConversationData(activity.ChannelId, activity.Conversation.Id);
                BotData privateConversationData = sc.BotState.GetPrivateConversationData(activity.ChannelId, activity.Conversation.Id, activity.From.Id);


                myUserString = userData.GetProperty<string>("myUserString") ?? "";
                myConversationString = userData.GetProperty<string>("myConversationString") ?? "";
                myPrivateConversationString = userData.GetProperty<string>("myPrivateConversationString") ?? "";

                if (myUserString == "")
                {
                    userData.SetProperty<string>("myUserString", "userData: " + activity.Text + " from user data \n\n");
                    sc.BotState.SetUserData(activity.ChannelId, activity.From.Id, userData);
                    str.Append("userData: " + activity.Text + " from user data \n\n");
                }
                else
                {
                    str.Append("userData: " + myUserString + " from user data \n\n");
                }


                if (myConversationString == "")
                {
                    userData.SetProperty<string>("myConversationString", "conversationData: " + activity.Text + " from conversation data  \n\n");
                    sc.BotState.SetConversationData(activity.ChannelId, activity.Conversation.Id, userData);
                    str.Append("conversationData: " + activity.Text + " from conversation data \n\n");
                }
                else
                {
                    str.Append("conversationData: " + myConversationString + " from conversation data \n\n");
                }


                if (myPrivateConversationString == "")
                {
                    userData.SetProperty<string>("myPrivateConversationString", "privateConversationString: " + activity.Text + " from private conversation data \n\n");
                    sc.BotState.SetPrivateConversationData(activity.ChannelId, activity.Conversation.Id, activity.From.Id, userData);
                    str.Append("privateConversationString: " + activity.Text + " from private conversation data \n\n");
                }
                else
                {
                    str.Append("privateConversationString: " + myPrivateConversationString + " from private conversation data \n\n");
                }

                Activity reply = activity.CreateReply(str.ToString());
                await connector.Conversations.ReplyToActivityAsync(reply);
            }
            else
            {
                HandleSystemMessage(activity);
            }
            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        private Activity HandleSystemMessage(Activity message)
        {
            if (message.Type == ActivityTypes.DeleteUserData)
            {
                // Implement user deletion here
                // If we handle user deletion, return a real message
            }
            else if (message.Type == ActivityTypes.ConversationUpdate)
            {
                // Handle conversation state changes, like members being added and removed
                // Use Activity.MembersAdded and Activity.MembersRemoved and Activity.Action for info
                // Not available in all channels
            }
            else if (message.Type == ActivityTypes.ContactRelationUpdate)
            {
                // Handle add/remove from contact lists
                // Activity.From + Activity.Action represent what happened
            }
            else if (message.Type == ActivityTypes.Typing)
            {
                // Handle knowing tha the user is typing
            }
            else if (message.Type == ActivityTypes.Ping)
            {
            }

            return null;
        }
    }
}