﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;

namespace StateDialog
{
    [Serializable]
    public class StateSampleDialog : IDialog<object>
    {
        private string userName;
        private string cityName;
        
        public async Task StartAsync(IDialogContext context)
        {
            await context.PostAsync("Hi There!! Lets get started !!");
            context.Wait(GetStarted);
        }

        public virtual async Task GetStarted(IDialogContext context, IAwaitable<object> result)
        {
            var name = await result;

            await context.PostAsync("Please provide your name !!");
            context.Wait(NameFromUserMethod);
        }

        public virtual async Task NameFromUserMethod(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var incomingMessage = await result;
            userName = incomingMessage.Text;


            await context.PostAsync("Please provide your City name !!");
            context.Wait(CityFromUserMethod);
        }

        public virtual async Task CityFromUserMethod(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var incomingMessage = await result;
            cityName = incomingMessage.Text;

            await context.PostAsync($"Hello {userName} !! do you want to know which city you entered ??");
            context.Wait(GetCityFromUserMethod);
        }

        public virtual async Task GetCityFromUserMethod(IDialogContext context, IAwaitable<IMessageActivity> result)
        {

            var answer = await result;

            await context.PostAsync($"Hello {userName} !! You entered {cityName} ??");
            context.Wait(GetStarted);
        }

        
    }
}